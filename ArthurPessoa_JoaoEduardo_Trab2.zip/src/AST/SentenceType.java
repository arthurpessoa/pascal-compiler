

package AST;

public class SentenceType extends Type {
    public SentenceType() {
        super("string");
    }
    
   public String getCname() {
      return "string";
   }
}
