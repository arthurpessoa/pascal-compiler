
package AST;

public class Subhead {
    protected String pid;
    private Dcls dcls;
    
    public Subhead(Dcls dcls, String pid){
        this.dcls = dcls;
        this.pid= pid;
    }
    public void genC( PW pw ) {
        dcls.genC(pw,false);
        
    }
}
