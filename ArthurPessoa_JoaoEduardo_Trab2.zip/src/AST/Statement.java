package AST;

abstract public class Statement {
    abstract public void genC( PW pw );
}
