package AuxComp;


public class StatementException extends Exception {
}
